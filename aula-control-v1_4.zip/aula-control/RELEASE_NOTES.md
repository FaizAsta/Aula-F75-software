## What's new in 1.4.0

- **New:** AULA F75 Max support (experimental), with its own screen.
- **F75 Max:** 20 effects with colour, brightness, speed and direction; per-key colours (USB-C only); key response, sleep, key locks and F-key swap; battery over the 2.4G dongle.
- **F75 Max:** built from other people's protocol notes and not tested on a real one, so it may not work. The keyboard can't be read back, so the screen shows what was last sent.
- **F75 Max:** no key remapping or screen support.
- **Safe by default:** other AULA models are left alone. A device is only used as an F75 Max if its name says so, and unknown names ask you to confirm first.
- **Fixed:** Keys tab "key layer too short" error on keyboards that send shorter layers.
- **Fixed:** per-key colours shifted on 384-byte colour blocks.
- **Fixed:** demo keyboard showed the wrong key names on the F87.
- **Fixed:** Software Update window buttons and a few layout glitches (header text cut off, things showing through the Apply bar, multicolour swatch wrapping).
