## What's new in 1.3.3

- **Software updates.** The app now checks GitHub for a newer version every time it starts, and every few hours while it's open. When one is found, a green download icon appears in the header and on the start screen. Click it to read the release notes, then press **Update now**. The installer downloads inside the app and is checked before it is used. When it's ready, you choose **Install now** or **Later**. Nothing installs until you say yes.
- **Check for updates.** There is a new **Software update** row in Settings with a **Check for updates** button, and a switch to turn the automatic check off. The portable version opens the release page in your browser instead, because a running file can't replace itself.
- **Transmission animation.** While settings go to the keyboard, the Apply bar shows a live link (Preparing, Transmitting, Verifying) and the preview shows a scan line and signal rings. It ends green with a tick, or amber or red if the keyboard didn't keep everything. Refresh and Read battery play it in reverse.
- **Button animations.** Click ripples in the keyboard's colour, spinners on buttons that wait for the keyboard, and small reactions on switches, effect tiles and window buttons.
- **Smoother transitions.** Tabs slide in, cards rise one after another, and messages and toasts fade instead of popping.
- All animations switch off with the system's reduced-motion setting.

## Fixed

- The Software Update window's buttons were misaligned, and the main button was invisible on the start screen.
- The header's connection label and battery text no longer get cut off or overlap the tabs at small window sizes.
- The keyboard drawing no longer shows through the "No keyboard found" message.
- Swatches and buttons no longer show through the Apply bar when you scroll.
- The multicolour swatch no longer wraps onto its own line at the minimum window width.
