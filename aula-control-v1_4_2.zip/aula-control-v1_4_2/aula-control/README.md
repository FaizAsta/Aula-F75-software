<div align="center">

<img src="docs/banner.png" width="800" alt="Aula Control">

**An unofficial Windows app for AULA F75 keyboards.**<br>
Battery, lighting effects, per-key RGB and a live preview.

[![Version](https://img.shields.io/badge/version-1.4.2-blue)](../../releases)
[![Platform](https://img.shields.io/badge/platform-Windows%2010%20%7C%2011-0078d4)](#download)

[**Download**](../../releases) · [Features](#features) · [Troubleshooting](#troubleshooting)

![Aula Control, Lighting tab](docs/screenshots/lighting.png)

</div>

## Read this first

I made this app for myself because AULA's official software is bad and its UI is terrible. I'm sharing it for anyone
who wants to try it. It's free, and you use it on your own.

I don't even know coding, so **use it at your own risk**, or leave if you have any issue. It was made with the help of
AI. If you have a personal problem with that, you're free to leave. I'm not earning anything from it, so I don't need to
worry about it. I just want to share.

**Tested only on the AULA F75.** Every other model (F75 Pro, F87, F75 Max) is untested, so I don't know if it works.
If you get an error, comment on the release.

Not affiliated with AULA.

## Download

Get **Aula-Control-Setup.exe** from [Releases](../../releases) and run it. No admin needed.
A portable **Aula-Control-Portable.exe** is there too.

Windows may warn about an unknown publisher because the app isn't code-signed: choose *More info, Run anyway*.
No keyboard? Try **Settings, Demo keyboard**.

## Features

- Battery level, charging indicator and low / fully charged alerts
- 15 lighting effects and per-key RGB
- Live preview of the keyboard as a rendered picture, a different one for each model (F75, F75 Pro, F87, F75 Max)
- Key assignment (experimental)
- Dark and light themes, tray icon, start with Windows

![The picture for each model: F75, F75 Pro, F87 and F75 Max](docs/screenshots/keyboards.png)

## The keyboard pictures

The pictures in `src/img/board` are rendered, not photographed: they are made from each model's layout and colours (`src/js/layout.js`, `src/js/skins.js`) by a small renderer that needs only Python with numpy, scipy and Pillow. To change a colourway or add a model, edit those files and run:

```
node scripts/render-board/dump-models.js > models.json
python3 scripts/render-board/render.py models.json --out src/img/board --R 128 --ss 2 --caps all
```

(about two minutes). `--only f75` renders one skin, `--R` is the size in pixels per key and `--ss` the supersampling. Without the images the app draws the keyboard with shapes instead. The F75 Max board (shown only when a Max is connected) is still drawn with CSS.

## Preset backgrounds

Every PNG, JPEG or WebP picture in `src/img/backgrounds` is offered in **Settings > Theme > Preset backgrounds**. None is
chosen by default. To add one, drop the file in that folder and rebuild with `npm run dist` (or *Build Windows App.bat*);
the build packs the folder into the app, and there is no list to edit. The file name becomes the label.

## Troubleshooting

- Close the official AULA driver. Only one program can use the keyboard at a time.
- Lighting works over the 2.4G dongle (best) or USB-C cable. Bluetooth only gives the battery level.
- Still stuck? Open **Settings, Connection help** and save a log.

---

*Made with the help of AI.*
