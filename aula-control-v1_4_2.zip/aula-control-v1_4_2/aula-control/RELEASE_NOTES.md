## What's new in 1.4.2

- **Preset backgrounds**
- **Background opacity slider**
- **Add your own presets by dropping files in a folder**

## What's new in 1.4.1

- **More brightness levels:** the app no longer stops at level 4. It reads the real level from the keyboard (before, anything above 4 was shown as 4), learns how many levels the keyboard has when it reports a higher one, for example after you raise it with the keyboard's own brightness keys, and then offers all of them in Lighting as a slider (arrow keys, Home and End work too). Settings > Keyboard tools > Brightness levels sets the number by hand (4 to 9). The preview glow follows the new scale.
- **Settings in four pages:** a switcher at the top of Settings opens one page at a time. **Keyboard** has the connection, the keyboard model, Keyboard tools (restore after a reset, brightness levels, demo keyboard) and Backup. **App** has the theme, the tray, start with Windows and updates. **Theme** has the custom background. **Debugging** is last: Save log, Save compatibility report, the detected interfaces and Connection help, which is no longer a folded section. Settings opens on Keyboard.
- **Custom background:** Settings > Theme > Background lets you pick a picture (PNG, JPEG or WebP) that is shown behind the whole app at 50% opacity. The app keeps its own shrunk copy (longest side 1920 px), so it keeps working if you move or delete the original, and it is remembered after a restart. Remove puts the plain look back. The start screen keeps its own look.
- **Simpler header:** the theme button and the refresh button are gone from the top bar (the theme is chosen in Settings > Appearance; refresh is F5 or Ctrl+R, and Settings > Keyboard has Search again). The header now holds just the connection status, the battery and the update badge.
- **Plain window buttons:** minimize, maximize and close no longer sit in a rounded glass pill. They are three flat buttons that show a soft square highlight (red for close) when you point at them.
- **One way to the battery:** the Battery tab is gone from the tab bar, because the battery pill in the header opens the same screen. The pill lights up while that screen is open.
- **Navbar icons:** the tabs (Lighting, Per-key, Keys, Battery, Settings) now show an icon for each section instead of its name; hover an icon to see the name. The Keys tab's "Experimental" pill is now a small amber dot on its icon.
- **New keyboard picture:** the preview is drawn like the manufacturer's own picture: dark case, grey keycaps with the legends printed on them, gold-sided Esc / Enter / arrows, a metal knob and the light glowing along the slots between the keys.
- **Rendered pictures:** the case and every keycap are now rendered images made with a small 3D-style renderer (real keycap shapes with a rounded shoulder and a dished top, black or coloured sides, soft shadows and occlusion between keys, glossy case, brushed-metal knob), instead of being drawn with shapes. The lighting, key presses, painting and hover are still added live on top, and painted keys keep the shading of the cap underneath. If the pictures cannot be loaded the app falls back to the drawing from 1.4.1. They are rebuilt with `scripts/render-board` (see the README).
- **Clearer:** the keyboard fills more of the preview (the preview area is taller and the margins are smaller), legends are larger, semi-bold and all one size, key caps are darker so the text stands out, the glow round each key is finer, and the caps are drawn on whole pixels so their edges stay sharp. "Delete" is printed "Del" so it fits its key.
- **A different picture for each model:** AULA F75 (black and gold), F75 Pro (silver and blue, bigger knob), F87 / F87 Pro (carbon and orange, no knob) and F75 Max (graphite and green, knob and a small screen). Switching the model in Settings switches the picture.
- **F75 Max:** its per-key board uses the Max picture too.
- **Keys tab:** now marked Experimental, on the tab and at the top of its panel.
- The lighting effects, per-key painting and key assignment work on the new picture as before. In Per-key and Keys the keys that are off are dimmed so painted ones stand out.

## What's new in 1.4.0

- **New:** AULA F75 Max support (experimental), with its own screen.
- **F75 Max:** 20 effects with colour, brightness, speed and direction; per-key colours (USB-C only); key response, sleep, key locks and F-key swap; battery over the 2.4G dongle.
- **F75 Max:** built from other people's protocol notes and not tested on a real one, so it may not work. The keyboard can't be read back, so the screen shows what was last sent.
- **F75 Max:** no key remapping or screen support.
- **Safe by default:** other AULA models are left alone. A device is only used as an F75 Max if its name says so, and unknown names ask you to confirm first.
- **Fixed:** Keys tab "key layer too short" error on keyboards that send shorter layers.
- **Fixed:** per-key colours shifted on 384-byte colour blocks.
- **Fixed:** demo keyboard showed the wrong key names on the F87.
- **Fixed:** Software Update window buttons and a few layout glitches (header text cut off, things showing through the Apply bar, multicolour swatch wrapping).
