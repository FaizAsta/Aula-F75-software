<!--
  KEEP THE SCREENSHOTS UP TO DATE (note for anyone who edits this project, people and AI assistants alike).

  Whenever the UI changes in any way (layout, colours, text, icons, a tab, setting, dialog or screen added, moved,
  renamed or removed), the screenshots in docs/screenshots must be updated in the same change, and the gallery in
  the "Screenshots" section below must match them:

    1. Existing screen changed: run   npm run screenshots   and commit the new pictures.
    2. New screen or state: add a scene for it in scripts/screenshots.js, run the script, and add the new
       picture to the "Screenshots" section below.
    3. Screen removed: delete its scene and its picture, and remove it from the "Screenshots" section.

  One-time setup:  npm install --no-save playwright sharp   then   npx playwright install chromium
  (sharp is optional; it makes the pictures about 4x smaller). `npm run screenshots -- --list` shows the scene
  names, and `npm run screenshots -- lighting battery` redraws only those. The pictures show the real UI with a
  simulated keyboard, so no hardware is needed. `npm test` checks that every picture in the folder is used here
  and every picture used here exists.
-->

<!--
  BUMPING THE VERSION (note for anyone who edits this project, people and AI assistants alike).

  When the version is bumped, change only the version number: in package.json ("version") and in the Version
  badge below (the X.Y.Z in badge/version-X.Y.Z-blue). The only other edit is the new header at the top of
  RELEASE_NOTES.md (see the note at the top of that file). Change nothing else: no README text, no screenshots,
  no tests. `npm test` checks that the two numbers agree.
-->

<div align="center">

<img src="docs/banner.png" width="800" alt="Aula Control">

**An unofficial Windows and Linux app for AULA F75 keyboards.**<br>
Battery, lighting effects, per-key RGB and a live preview.

[![Version](https://img.shields.io/badge/version-1.5.1-blue)](../../releases)
[![Platform](https://img.shields.io/badge/platform-Windows%2010%20%7C%2011%20%7C%20Linux-0078d4)](#download)
[![Discord](https://img.shields.io/badge/Discord-join%20the%20server-5865F2?logo=discord&logoColor=white)](https://discord.gg/BdeQygyRwN)

[**Download**](../../releases) · [Features](#features) · [Troubleshooting](#troubleshooting) · [Discord](https://discord.gg/BdeQygyRwN)

![Aula Control, Lighting tab](docs/screenshots/lighting.png)

</div>

## New: Liquid glass UI (experimental)

Aula Control now has a second look: **Liquid glass**. Panels, buttons, switches, sliders, scroll bars and the update
progress bar become glass that bends and blurs the picture behind them, a bit like iOS. **Classic** is still the default.

The first time you press **Start** (a new install, or an update from a version that did not ask), the app asks **"Which UI do you want to use?"**
and shows both looks side by side. Pick one and press **Continue**. It is asked only once, and you can change your mind
any time in **Settings, Theme, UI**.

<div align="center">

<img src="docs/screenshots/lighting-glass.png" alt="The Lighting tab in Liquid glass, over the built-in background picture" width="760">

<sub>The Lighting tab in Liquid glass, over the built-in background picture</sub>

</div>

> [!CAUTION]
> **Liquid glass is experimental.** It is **not stable** and it **can be laggy**, more so on weaker or older computers.
> It may also look off or glitch in places, and I have not tested it everywhere. It looks best with a background picture
> (Settings, Theme). If anything misbehaves, switch back to **Classic** in the same place. Nothing else is affected.

## Read this first

I made this app for myself because AULA's official software is bad and its UI is terrible. I'm sharing it for anyone
who wants to try it. It's free, and you use it on your own.

I don't even know coding, so **use it at your own risk**, or leave if you have any issue. It was made with the help of
AI. If you have a personal problem with that, you're free to leave. I'm not earning anything from it, so I don't need to
worry about it. I just want to share.

**Tested only on the AULA F75.** Every other model (F75 Pro, F87, F75 Max) is untested, so I don't know if it works.
If you get an error, comment on the release.

Not affiliated with AULA.

## Download

Get **Aula-Control-Setup.exe** from [Releases](../../releases) and run it. No admin needed.
A portable **Aula-Control-Portable.exe** is there too.

Windows may warn about an unknown publisher because the app isn't code-signed: choose *More info, Run anyway*.
No keyboard? Try **Settings, Demo keyboard**.

**Linux (64-bit, new and untested):** get one of these from [Releases](../../releases).

- **Aula-Control-amd64.deb** for Ubuntu, Debian, Mint and Pop!_OS. Double-click it and press Install (or run
  `sudo apt install ./Aula-Control-amd64.deb`). It also sets up keyboard access, so unplug and plug the keyboard once after installing.
- **Aula-Control-x86_64.AppImage** for any other distro. Right-click it, Properties, allow executing as a program, then double-click it.
  Keyboard access needs one step the AppImage cannot do itself: download **99-aula-control.rules** from the same release and run
  `sudo cp 99-aula-control.rules /etc/udev/rules.d/ && sudo udevadm control --reload-rules && sudo udevadm trigger`,
  then unplug and plug the keyboard.

On Linux the app does not update itself: it tells you a new version is out and opens the release page. *Start with Windows* does nothing there.

## Community

Join the [Discord server](https://discord.gg/BdeQygyRwN) to share ideas, ask for help or tell us about a problem. Ideas for new features are welcome.

In the app, press **Support** (on the start screen and in the top bar) for the Discord invite and the other links.

## Features

- Battery level, charging indicator and low / fully charged alerts, with a red breathing light on the keyboard while the battery is low
- After an update, a small window lists what is new (only the headers from RELEASE_NOTES.md, not the descriptions)
- 15 lighting effects and per-key RGB
- Live preview of the keyboard as a rendered picture, a different one for each model (F75, F75 Pro, F87, F75 Max); a Live / Picture switch on it: Live follows the keyboard and goes dark when it is off or asleep, Picture is only a still image of the board in its current light colours, with no animation, no pointer effects and nothing laid over it
- Key assignment (experimental)
- Dark and light themes, tray icon, start with Windows
- Liquid glass UI (experimental, not stable, can be laggy): an optional second look, offered once after Start ("Which UI do you want to use?") and in Settings > Theme > UI; Classic stays the default
- Blur switch (Classic UI only): Settings > Theme > Blur turns the frosted blur behind the tabs, cards, tiles and pop-ups on or off

<img src="docs/screenshots/keyboards.png" alt="The picture for each model: F75, F75 Pro, F87 and F75 Max" width="560">

## Screenshots

All of these are the real app with a simulated keyboard (the Demo keyboard, or a simulated dongle, cable or F75 Max).
Click a picture to see it full size.

### Start and devices

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/start.png"><img src="docs/screenshots/start.png" alt="The start screen" width="430"></a><br><sub>Start screen</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/style-picker.png"><img src="docs/screenshots/style-picker.png" alt="The question Which UI do you want to use, with Classic and Liquid glass" width="430"></a><br><sub>After Start, once: Which UI do you want to use? (Classic or Liquid glass)</sub></td>
</tr>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/devices.png"><img src="docs/screenshots/devices.png" alt="The list of connected devices" width="430"></a><br><sub>Connected devices: dongle, USB-C cable and the demo keyboard</sub></td>
<td></td>
</tr>
</table>

### Lighting and per-key

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/lighting.png"><img src="docs/screenshots/lighting.png" alt="The Lighting tab" width="430"></a><br><sub>Lighting: 15 effects, brightness, speed and colour</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/sending.png"><img src="docs/screenshots/sending.png" alt="Sending settings to the keyboard, with the transfer animation" width="430"></a><br><sub>Apply: the transfer animation while settings are sent</sub></td>
</tr>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/per-key.png"><img src="docs/screenshots/per-key.png" alt="The Per-key tab with every key painted" width="430"></a><br><sub>Per-key: paint single keys or use a preset</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/light-theme.png"><img src="docs/screenshots/light-theme.png" alt="The Lighting tab in the light theme" width="430"></a><br><sub>The light theme</sub></td>
</tr>
</table>

### Keys (experimental)

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/keys.png"><img src="docs/screenshots/keys.png" alt="The Keys tab with Caps Lock changed to F13" width="430"></a><br><sub>Key assignment, here Caps Lock changed to F13 (nothing is sent until you press Apply)</sub></td>
<td width="50%"></td>
</tr>
</table>

### Battery

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/battery.png"><img src="docs/screenshots/battery.png" alt="The Battery screen with the activity chart" width="430"></a><br><sub>Battery level, estimate and activity history</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/charging.png"><img src="docs/screenshots/charging.png" alt="The Battery screen while charging over the cable on the 2.4G dongle" width="430"></a><br><sub>Charging, with the level read over the 2.4G dongle</sub></td>
</tr>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/charging-cable.png"><img src="docs/screenshots/charging-cable.png" alt="The Battery screen on the USB-C cable, which reports no level" width="430"></a><br><sub>Charging over the USB-C cable alone (the cable reports no level)</sub></td>
<td width="50%"></td>
</tr>
</table>

### Settings

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/settings.png"><img src="docs/screenshots/settings.png" alt="Settings, Keyboard page" width="430"></a><br><sub>Settings, Keyboard: connection, model, tools</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/settings-app.png"><img src="docs/screenshots/settings-app.png" alt="Settings, App page" width="430"></a><br><sub>Settings, App: tray, start with Windows, updates</sub></td>
</tr>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/settings-theme.png"><img src="docs/screenshots/settings-theme.png" alt="Settings, Theme page with the background pictures" width="430"></a><br><sub>Settings, Theme: dark or light, background picture and opacity, preset backgrounds</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/settings-debug.png"><img src="docs/screenshots/settings-debug.png" alt="Settings, Debugging page" width="430"></a><br><sub>Settings, Debugging: connection log and compatibility report</sub></td>
</tr>
</table>

### When the keyboard is not ready

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/connecting.png"><img src="docs/screenshots/connecting.png" alt="Reading your keyboard, waking it up" width="430"></a><br><sub>Reading the keyboard (waking it up)</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/asleep.png"><img src="docs/screenshots/asleep.png" alt="Keyboard is asleep" width="430"></a><br><sub>The keyboard is asleep: press any key</sub></td>
</tr>
</table>

### Support

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/support.png"><img src="docs/screenshots/support.png" alt="The Support menu with the Discord invite" width="430"></a><br><sub>The Support button opens the Discord invite and the other links</sub></td>
</tr>
</table>

### Updates and window buttons

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/update.png"><img src="docs/screenshots/update.png" alt="The Software Update window" width="430"></a><br><sub>Software update: new version, download size, Later or Update now</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/window-controls.png"><img src="docs/screenshots/window-controls.png" alt="The flat window buttons in each state" width="430"></a><br><sub>The window buttons: idle, hover, close hover and maximized</sub></td>
</tr>
</table>

### F75 Max (experimental)

<table>
<tr>
<td align="center" width="50%"><a href="docs/screenshots/max.png"><img src="docs/screenshots/max.png" alt="The F75 Max Lighting screen" width="430"></a><br><sub>F75 Max, Lighting: 20 effects</sub></td>
<td align="center" width="50%"><a href="docs/screenshots/max-perkey.png"><img src="docs/screenshots/max-perkey.png" alt="The F75 Max Per-key screen" width="430"></a><br><sub>F75 Max, Per-key colours</sub></td>
</tr>
</table>

## Troubleshooting

- Close the official AULA driver. Only one program can use the keyboard at a time.
- Lighting works over the 2.4G dongle (best) or USB-C cable. Bluetooth only gives the battery level.
- The red low-battery light is written by the app, so it only works while Aula Control is running. Hidden in the tray is fine; if you quit the app, nothing watches the battery. Turn on **Start with Windows** in Settings, App to keep it running. Hover the tray icon to see what the app uses right now (CPU and memory, measured by Electron).
- Still stuck? Open **Settings, Connection help** and save a log.

---

*Made with the help of AI.*
