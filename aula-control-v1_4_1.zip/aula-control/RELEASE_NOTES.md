## What's new in 1.4.1

- **New keyboard picture:** the preview is drawn like the manufacturer's own picture: dark case, grey keycaps with the legends printed on them, gold-sided Esc / Enter / arrows, a metal knob and the light glowing along the slots between the keys.
- **More realistic:** keycaps have a bevelled edge, a dished top, a soft highlight and a fine grain; the case has thickness, a chamfered edge and a drop shadow; the plate is a shadowed well; the knob is brushed metal with a knurled rim. The case and each keycap are drawn once and reused, so it stays light on the CPU, and the picture is sharper on high-DPI screens.
- The preview area is a little taller so the picture shows more detail.
- **A different picture for each model:** AULA F75 (black and gold), F75 Pro (silver and blue, bigger knob), F87 / F87 Pro (carbon and orange, no knob) and F75 Max (graphite and green, knob and a small screen). Switching the model in Settings switches the picture.
- **F75 Max:** its per-key board uses the Max picture too.
- **Keys tab:** now marked Experimental, on the tab and at the top of its panel.
- The lighting effects, per-key painting and key assignment work on the new picture as before. In Per-key and Keys the keys that are off are dimmed so painted ones stand out.

## What's new in 1.4.0

- **New:** AULA F75 Max support (experimental), with its own screen.
- **F75 Max:** 20 effects with colour, brightness, speed and direction; per-key colours (USB-C only); key response, sleep, key locks and F-key swap; battery over the 2.4G dongle.
- **F75 Max:** built from other people's protocol notes and not tested on a real one, so it may not work. The keyboard can't be read back, so the screen shows what was last sent.
- **F75 Max:** no key remapping or screen support.
- **Safe by default:** other AULA models are left alone. A device is only used as an F75 Max if its name says so, and unknown names ask you to confirm first.
- **Fixed:** Keys tab "key layer too short" error on keyboards that send shorter layers.
- **Fixed:** per-key colours shifted on 384-byte colour blocks.
- **Fixed:** demo keyboard showed the wrong key names on the F87.
- **Fixed:** Software Update window buttons and a few layout glitches (header text cut off, things showing through the Apply bar, multicolour swatch wrapping).
